clc
clear all

fhd = @cec17_func;
problem_size = 2;
pop_size = 10000;
GBEST = [-55.2763984982280,-70.4295597180862;
    -29.3411706152098,-17.0545298313045;
    -55.9383267052184,4.54306539359646;
    32.5107250141495,7.75531281146934;
    -17.4084503657224,56.1747033038059;
    79.0893929447464,-24.5727776477918;
    -46.5875840776542,42.4744068656463;
    32.1642193720510,-55.9650139398710;
    -24.8562542837375,0.934253223675427;
    -21.8715135482473,-74.5282053921969;
    64.3468845562762,12.7073523014352;
    -14.3868047587512,70.9245106833635;
    52.8981569953720,-2.53749621777679;
    61.7701642353880,-8.24035507824289;
    9.58570113479425,73.2840697436054;
    49.1789997002012,7.43830158907841;
    -62.3918096937201,45.3186986955435;
    70.3203046574818,-58.6176003118128];
f = [];
for i = 1 : 2%18
    if i <=10
        f = [f;cec17_func(GBEST(i,:)',i)];
    else
        i = i + 10;
        f = [f;cec17_func(GBEST(i-10,:)',i)];
    end
end
lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
nfes = 0;
pop = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
%%
for func = 1:18
    figure
    x = [-100:1:100]';
    y = [-100:1:100]';
    [X, Y] = meshgrid(x, y);
    for i = 1 : 201
        for j = 1 : 201
            if func <= 10
                Z(i,j) = feval(fhd,[X(i,j) Y(i,j)]',func);
            else
                Z(i,j) = feval(fhd,[X(i,j) Y(i,j)]',func + 10);
            end
        end
    end
    surf(X, Y, Z);
    hold on
    %         colormap('jet');
    %     colormap('cool');
    %         colormap('summer');
    %         colormap('hsv');
    %         colormap('Winter');
    %         colormap('Lines');
    %         colormap('hot');
    colormap('Parula');
    %     mesh(X, Y, Z);
    %         contour(X,Y,Z,100);
    shading flat
    %   shading interp
    %     shading faceted
    %     scatter3(GBEST(func,1),GBEST(func,2),f(func,:),100,'r*')
    hold on
    
    %     if func <= 10
    %         scatter3(pop(:,1),pop(:,2),feval(fhd,pop',func),'r.');
    %         hold on
    %     else
    %         scatter3(pop(:,1),pop(:,2),feval(fhd,pop',func+10),'r.');
    %         hold on
    %     end
    %     shading faceted
    %     shading interp
    if func <= 10
        name = ['F',num2str(func)];
        title(name);
    else
        name = ['F',num2str(func+10)];
        title(name);
    end
    x1=xlabel('x1');
    x2=ylabel('x2');
    x3=zlabel('f(x)');
    view(-60,20)
    %         axis equal
    %     axis off vis3d;
    
end
%%
% i = 1;
% t = 0:1:10000;
% for i = 2:length(t)
%     view(-115-t(i),40);
%     pause(0.02)
% end